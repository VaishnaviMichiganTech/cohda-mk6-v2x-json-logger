## Overview
This directory contains instructions on how to create
a working set of configuration files with 1609.2.1 enrollment
(e.g. ../ieee-OmniAir-2024) from the generis ieee configuration
files (e.g. ../ieee)

This directory contans patches to be applied to the ../ieee sample configuration files.
The result should match teh working ../ieee-OmniAir-2024 files.
The intent is to demonstrate what changes are necessary and aid in
applying these changes to future scenatios.

## Preparation

### 0001-Remove-unused-files-see-16480.patch
We'll be downloading the root keys from the SCMS server so there's no need to have
a local demo key.


### 0002-Select-PKI-type-see-16480.patch
Make sure you set the PKI type.


### 0003-Update-the-enrollment-configuration-file-see-16480.patch
Update the enrollment configuration file to ensure the parameters match
EXACTLY what the SCMS back-end serer offers:
- permissions rquested by the device
- the operating region
- crypto parameters (curve, type)

Consult with your SCMS provider to obtain the exact details.
Set the "canonical\_id" to a placeholder value for now.


### 0004-Update-the-PKI-server-configuration-file-see-16480.patch
Ensure your PKI server configuration file is updated with the parameters
provided by the back-end server provider.
Take care to use the correct URLs as some providers offer both a paid "live"
service ad a free "playpen" service.


### 0005-Update-the-security-context-see-16480.patch
Another file that must be updated to match the requirements of the SCMS.
Note that this file requires the information provided by the SCMS and the
format requirements for the Aerolin library.
You may well require assistence (i.e. from Qualcomm) to ensure thsi file is correct.


## Helper Scripts

The device should now be ready to start the enrollment.

This is likely to be an iterative process. Debug information
(e.g. logs, console output etc.) may need to be provided to
third parties in order to receive assistance.

It is highly recommended that you make use of the following helper scripts
(found in ../../tools/misc) to reliably capture this information:

### SSH\_to\_MK6
Script to start a SSH console on the MK6 while capturing the output to the host system.
The "mk6" is assumed to be bookmarked in your ~/.ssh/config file.

### aerolink\_bash
Commands to be sourced on the device to set up the AEROLINK environment.
Any time you want to run an aerolink tool on the commandline you have to set up
various parameters (PATH, LD\_LIBRARYPATH, AEROLINK\_* parameters) etc.

### Harvest\_MK6
Script executed on the host to collect all the relevant data from the device.
This should provide all the information encessary to diagnose the device state
(i.e. logs, the aerolink directory etc.


## Procedure
Install the latest example1609 and customize aerolink configuration files.

Note that the parameters and files required by the registration utilities may vary.

Create an enrollment request:

    SSH_to_MK6
    . ./aerolink_bash
    createIeeeEndEntityRegistration --generateCanonicalId  --curve NISTP256

This will create the canonical ID and key, e.g.:

    Canonical ID: 88...62
    Canonical public key: 80...f7

Replace the placeholder values in enrollment.conf with the actual canonical ID.
Use the canonical ID and public key to create an enrolment request.

Process the registration
    SSH_to_MK6
    . ./aerolink_bash
    processIeeeEndEntityRegistration --ccf /mnt/ubi/PLUGFEST/bootstrap/cert-chain_4.oer --crl /mnt/ubi/PLUGFEST/bootstrap/composite-crl_32.oer

You should now be able to start your ITS application.
Make sure you have verbose AEROLINK debug enabled.
Capture the state of the system after a few minutes.
Ideally your system will now be signing outgoing BSMs.

## Gotchas

Some of the things that can go wrong:

- MK6 lost IPv4 route, needed "dhclient -r" to restore.
- incorrect URLs in pkiserve.conf
- parameters not matching what the SCMS offers
- mismatching parameters in the various parameter files
- left-over files in the aerolink/state directory
- registering with the wrong SCMS ("production" rather than "pre-production")
- trying to use out-dated "bootstrap" files



