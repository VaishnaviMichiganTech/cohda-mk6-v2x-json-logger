#!/bin/sh
# Update for Microsec V2X Root CA (DCA3229227BFBE74)
# 0_Microsec-CCMS-RCA-2023-1_L0
# http://microsec-ccms-dc-2023-1-l0.v2x-pki.com

# CA is in the ECTL
./fetch-cpoc.sh

set -x

# Get CRL/CTL for this CA
wget --no-verbose https://microsec-ccms-dc-2023-1-l0.v2x-pki.com/getctl/DCA3229227BFBE74 -O ctl
wget --no-verbose https://microsec-ccms-dc-2023-1-l0.v2x-pki.com/getcrl/DCA3229227BFBE74 -O crl

