#!/bin/sh
# Update for CPOC
# Updated for L0 ECTL v21 release

set -x

# Fetch latest known TLM, then get latest ECTL signed by that TLM
wget --no-verbose https://cpoc.jrc.ec.europa.eu/L0/gettlmcertificate/8FFE810BDB0D71E6 -O tlm
wget --no-verbose https://cpoc.jrc.ec.europa.eu/L0/getectl/8FFE810BDB0D71E6 -O ectl

