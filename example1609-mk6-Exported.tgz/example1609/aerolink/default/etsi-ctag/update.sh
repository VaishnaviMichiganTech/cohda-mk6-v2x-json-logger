#!/bin/sh
# Update for 0_CTAG-ROOT-CA_L0 (DBF851D9AFAB2EFE)

# CTAG RCA is in the ECTL
./fetch-cpoc.sh

set -x

# Get CRL/CTL for this CA
wget --no-verbose http://1.ctag-dc.l0.siscoga4cad.com/DC/getcrl/DBF851D9AFAB2EFE -O crl
wget --no-verbose http://1.ctag-dc.l0.siscoga4cad.com/DC/getctl/DBF851D9AFAB2EFE -O ctl

