#!/bin/bash
echo ""
echo "$0 $1 $2 $3"

APP_DIR=
APP_NAME=
PERSIST_DIR=
 
Display_help()
{
  echo ""
  echo "Usage: ./OAplugtest.sh {APP_NAME} {ZIP_FILE} | {CERT_NUM}"
  echo "      APP_NAME is the Application name, such as rsuNA, tcia, exampleETSI, example1609 and exampleCN, etc."
  echo "      ZIP_FILE is the bundle ZIP file, Mandotary"
  echo "      CERT_NUM is the suit number if there are many cert suits. As default, it is 0. Optional"
  echo "      "
}


################# Variables ###########################
NEW_CERTS=
RSU_NUM=0
RSU_CNT=0
CERT_BUNDLE_ZIP=
CERT_BUNDLE_DIR=

if [[ $# -lt 3 || "$1" == "-h" || "$1" == "--help" ]]; then
  Display_help
  exit 1
fi

if [[ -n "$1"  ]]; then
  case $1 in
    "rsuNA")
      APP_NAME=$1
      APP_DIR="/opt/cohda/application/$1"
      ;;
    "tcia" | "example1609") 
      APP_NAME=$1
      APP_DIR="/mnt/rw/$1"
      ;;
    *)
      echo "No $1 application, check again."
      exit 1
      ;;
  esac
fi

PERSIST_DIR="/mnt/rw/${APP_NAME}"
if [[ -n $2 && -e $2 ]]; then
  CERT_BUNDLE_ZIP=$2
else
  echo "OOPs, Check Certs ZIP file First"
  exit 1
fi

if [[ $# -eq 3 ]]; then
  RSU_NUM=$3
fi

################# CERTs Bundle #######################

PLUGFEST_DIR="Plugfest"
if [[ -e ./${PLUGFEST_DIR} ]]; then
  rm -rf ./${PLUGFEST_DIR}
fi

mkdir -p ${PLUGFEST_DIR}
unzip -q ${CERT_BUNDLE_ZIP} -d ${PLUGFEST_DIR} 

NEW_CERTS=$(pwd)
CERT_DIR=`ls ${PLUGFEST_DIR}`

NEW_CERTS+="/${PLUGFEST_DIR}"
NEW_CERTS+="/${CERT_DIR}"

RSU_CNT=`ls -l ${NEW_CERTS}/ | grep rsu- | wc -l`

if [[ ${RSU_CNT} -gt 0 ]]; then
  echo "In ${CERT_BUNDLE_ZIP}, there are ${RSU_CNT} cert suits."
  NEW_CERTS+="/rsu-${RSU_NUM}"
fi

if [[ ! -d ${NEW_CERTS} ]]; then
  echo "OOPs, No ${NEW_CERTS}. Check it."
  echo
  exit 1
else
  echo "   APP_NAME: ${APP_NAME}"
  echo "    APP_DIR: ${APP_DIR}"
  echo "PERSIST_DIR: ${PERSIST_DIR}"
  echo "Now, we are using ${NEW_CERTS}"
fi

echo 

################# TCIA ###############################
TCIA_DIR="${PLUGFEST_DIR}/tcia"

if [[ -e ${TCIA_DIR} ]]; then
  (set -x; rm -rf ${TCIA_DIR})
fi

tar -xf tcia-mk6-*.tgz -C ./${PLUGFEST_DIR}/

TCIA_GHS="${TCIA_DIR}/ghs"

if [[ ! -e ${TCIA_GHS} ]]; then
  echo "No ${TCIA_GHS}"
  exit 1
fi

################# Local Functions #####################

_Stop_CW_Application()
{
if [[ "${APP_NAME}" == "rsuNA" ]]; then
  systemctl stop cw-mkx-application
else
  (set -x; ${APP_DIR}/rc.${APP_NAME} stop)
fi
}

_Copy_GHS_CERTS()
{
if [[ -e /mnt/rw/certs ]]; then
  rm -rf  /mnt/rw/certs
fi

  mkdir -p /mnt/rw/certs

  rm -rf /mnt/rw/certs/*
  cp -rf ${TCIA_GHS}/* /mnt/rw/certs/
  rm -rf /mnt/rw/certs/download/*
  cp -rf ${NEW_CERTS}/* /mnt/rw/certs/download/
}

_Conf_Parameters()
{
if [[ ${APP_NAME} == "rsuNA" ]]; then
  sed -i 's/Dot2_MessageContextName      .*/Dot2_MessageContextName      = plugfest.wsc/'  /mnt/rw/rsuNA/conf/stack.conf
  sed -i 's/Dot2_IdChangeLcmName         .*/Dot2_IdChangeLcmName         = wsaLcm/'        /mnt/rw/rsuNA/conf/stack.conf
  sed -i 's/Cohda_Crypto_TestCountryCode .*/Cohda_Crypto_TestCountryCode = 840/'           /mnt/rw/rsuNA/conf/stack.conf
else
  if [[ -e /mnt/rw/obu.conf ]]; then
     rm -rf /mnt/rw/obu.conf
  fi

  touch /mnt/rw/obu.conf
  echo "Cohda_Crypto_AeroLogging     = all"          >>  /mnt/rw/obu.conf
  echo "Dot2_MessageContextName      = plugfest.wsc" >>  /mnt/rw/obu.conf
  echo "Dot2_IdChangeLcmName         = bsmLcm"       >>  /mnt/rw/obu.conf
  echo "Cohda_Crypto_TestCountryCode = 840"          >>  /mnt/rw/obu.conf
fi
}

_Init_Aerolink()
{
  ${APP_DIR}/rc.${APP_NAME} aerolink clear
  ${APP_DIR}/rc.${APP_NAME} aerolink na-ghs-sw-load /mnt/rw/certs
  ${APP_DIR}/rc.${APP_NAME} aerolink cert-check
}

_Modify_Parameter()
{
  sed -i 's/check_crl .*/check_crl false/'                ${APP_DIR}/aerolink/active/config/security-profile/*.prof
}

_Start_CW_Application()
{
if [[ "${APP_NAME}" == "rsuNA" ]]; then
  systemctl restart cw-mkx-application

  echo "restart cw-mkx-application"
else
  (set -x; ${APP_DIR}/rc.${APP_NAME} start obu)
fi
}

################# Main Procedure #####################

_Stop_CW_Application

_Copy_GHS_CERTS

_Conf_Parameters

_Init_Aerolink

_Modify_Parameter

_Start_CW_Application

